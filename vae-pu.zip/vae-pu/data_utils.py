import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras

def process_FashionMNIST(positive_label_list=[1,4,7], label_ratio=0.1):
    fashion_mnist = keras.datasets.fashion_mnist
    (image_tr_val, y_tr_val), (image_te, y_te) = fashion_mnist.load_data()
    x_tr_val = image_tr_val.reshape((image_tr_val.shape[0], -1))    # 将二维图片转换成一维
    x_te = image_te.reshape((image_te.shape[0], -1))
    y_tr_val = np.array([1 if ele in positive_label_list else -1 for ele in y_tr_val])   # 将类别映射为1和-1
    y_te = np.array([1 if ele in positive_label_list else -1 for ele in y_te])
    x_tr, x_val, y_tr, y_val = train_test_split(x_tr_val, y_tr_val, test_size=0.16, shuffle=True, stratify=y_tr_val)

    std_scaler = MinMaxScaler()
    x_tr = std_scaler.fit_transform(x_tr)  # 数据标准化
    x_val, x_te = std_scaler.transform(x_val), std_scaler.transform(x_te)
    label_num = int(label_ratio* x_tr.shape[0])  # 有标签的样本个数

    x_tr_p, y_tr_p, x_tr_n, y_tr_n = x_tr[y_tr==1,:],  y_tr[y_tr==1], x_tr[y_tr==-1,:],  y_tr[y_tr==-1] # 从训练集中分出正样本和负样本
    x_tr_l, y_tr_l = x_tr_p[:label_num, :], y_tr_p[:label_num]   # 从正样本中采样出有标签的样本
    x_tr_u = np.concatenate((x_tr_p[label_num:,:], x_tr_n), axis=0)  # 剩下的为无标签样本
    y_tr_u = np.concatenate((y_tr_p[label_num:], y_tr_n), axis=0)
    np.random.shuffle(x_tr_u)   # 随机打乱数据, 让无标签样本中的正负样本混合
    np.random.shuffle(y_tr_u)

    dct = {'x_tr_l': x_tr_l,
           'x_tr_u': x_tr_u,
           'y_tr_l': y_tr_l,
           'y_tr_u': y_tr_u,
           'x_val': x_val,
           'y_val': y_val,
           'x_te': x_te,
           'y_te': y_te}
    print(x_tr_l.shape, x_tr_u.shape)
    np.savez('./pu_data/fashionMNIST.npz', **dct)


def process_FashionMNIST_bias(positive_label_list=[1,4,7], bias_label_list=[1,4], label_ratio=0.1):
    fashion_mnist = keras.datasets.fashion_mnist
    (image_tr_val, y_tr_val), (image_te, y_te) = fashion_mnist.load_data()
    x_tr_val = image_tr_val.reshape((image_tr_val.shape[0], -1))  # 将二维图片转换成一维
    x_te = image_te.reshape((image_te.shape[0], -1))

    y_te = np.array([1 if ele in positive_label_list else -1 for ele in y_te])
    x_tr, x_val, y_tr, y_val = train_test_split(x_tr_val, y_tr_val, test_size=0.16, shuffle=True, stratify=y_tr_val)
    y_backup = y_tr    # 原先的类别
    y_tr = np.array([1 if ele in positive_label_list else -1 for ele in y_tr])  # 将类别映射为1和-1
    y_val = np.array([1 if ele in positive_label_list else -1 for ele in y_val])  # 将类别映射为1和-1
    std_scaler = MinMaxScaler(feature_range=(0,1))
    x_tr = std_scaler.fit_transform(x_tr)  # 数据标准化
    x_val, x_te = std_scaler.transform(x_val), std_scaler.transform(x_te)
    label_num = int(label_ratio * x_tr.shape[0])  # 有标签的样本个数
    x_tr_p, y_tr_p, x_tr_n, y_tr_n = x_tr[y_tr==1, :], y_tr[y_tr==1], x_tr[y_tr==-1, :], y_tr[y_tr==-1]  # 从训练集中分出正样本和负样本
    y_backup_p = y_backup[y_tr==1]
    slice = int(label_num/len(bias_label_list))

    x_tr_l = []
    y_tr_l = []
    x_tr_u = []
    y_tr_u = []
    for cat in bias_label_list:
        x_backup_p_cat = x_tr_p[y_backup_p==cat]
        y_backup_p_cat = y_tr_p[y_backup_p==cat]
        x_l_c, y_l_c = x_backup_p_cat[:slice], y_backup_p_cat[:slice]
        x_u_c, y_u_c = x_backup_p_cat[slice:], y_backup_p_cat[slice:]
        x_tr_l.append(x_l_c)
        y_tr_l.append(y_l_c)
        x_tr_u.append(x_u_c)
        y_tr_u.append(y_u_c)
    x_tr_l = np.concatenate(x_tr_l, axis=0)
    y_tr_l = np.concatenate(y_tr_l, axis=0)
    x_tr_u = np.concatenate(x_tr_u, axis=0)
    y_tr_u = np.concatenate(y_tr_u, axis=0)
    x_tr_u = np.concatenate((x_tr_u,x_tr_n), axis=0)
    y_tr_u = np.concatenate((y_tr_u,y_tr_n), axis=0)
    np.random.shuffle(x_tr_u)  # 随机打乱数据, 让无标签样本中的正负样本混合
    np.random.shuffle(y_tr_u)

    dct = {'x_tr_l': x_tr_l,
           'x_tr_u': x_tr_u,
           'y_tr_l': y_tr_l,
           'y_tr_u': y_tr_u,
           'x_val': x_val,
           'y_val': y_val,
           'x_te': x_te,
           'y_te': y_te}
    np.savez('./pu_data/fashionMNIST_bias.npz', **dct)


def process_page_blocks(path='./source/page-blocks.data', positive_label_list=[2,3,4,5], label_ratio = 0.1):
    '''
    x_tr_l: 有标签的训练数据    shape: (num, feat_dim)
    x_tr_u:  无标签的训练数据    shape: (num, feat_dim)
    y_tr_l:  有标签的数据的类别  shape: (num, )
    y_tr_u:  无标签的数据的类别   shape: (num, )
    x_val:   验证数据
    y_val:   验证数据的标签
    x_te:   测试数据
    y_te:   测试数据的标签
    '''
    columns = ["height", "lenght", "area", "eccen", "p_black", "p_and", "mean_tr", "blackpix", "blackand", "wb_trans",
               "class"]
    df = pd.read_csv(path, sep="\s+",names=columns, header=None)
    df['class'] = df['class'].apply(lambda x: 1 if x in positive_label_list else -1)   # 正样本类别设为1，负样本类别为-1
    data = np.asarray(df)
    x, y = data[:,:-1], data[:, -1]
    std_scaler = MinMaxScaler(feature_range=(0,1))


    ### 分割数据集, 训练集(60%), 验证集(20%)和测试集(20%)
    x_tr, x_val_te, y_tr, y_val_te = train_test_split(x, y, test_size=0.4, shuffle=True, stratify=y)
    x_val, x_te, y_val, y_te = train_test_split(x_val_te, y_val_te, test_size=0.5, shuffle=True, stratify=y_val_te)

    x_tr = std_scaler.fit_transform(x_tr)  # 数据标准化
    x_val, x_te = std_scaler.transform(x_val), std_scaler.transform(x_te)

    label_num = int(label_ratio* x_tr.shape[0])  # 有标签的样本个数
    x_tr_p, y_tr_p, x_tr_n, y_tr_n = x_tr[y_tr==1,:],  y_tr[y_tr==1], x_tr[y_tr==-1,:],  y_tr[y_tr==-1] # 从训练集中分出正样本和负样本
    x_tr_l, y_tr_l = x_tr_p[:label_num, :], y_tr_p[:label_num]   # 从正样本中采样出有标签的样本
    x_tr_u = np.concatenate((x_tr_p[label_num:,:], x_tr_n[label_num:,:]), axis=0)  # 剩下的为无标签样本
    y_tr_u = np.concatenate((y_tr_p[label_num:], y_tr_n[label_num:]), axis=0)
    np.random.shuffle(x_tr_u)   # 随机打乱数据, 让无标签样本中的正负样本混合
    np.random.shuffle(y_tr_u)

    dct = {'x_tr_l': x_tr_l,
           'x_tr_u': x_tr_u,
           'y_tr_l': y_tr_l,
           'y_tr_u': y_tr_u,
           'x_val': x_val,
           'y_val': y_val,
           'x_te': x_te,
           'y_te': y_te}

    # print(np.max(x_tr_l))
    np.savez('./pu_data/page-blocks.npz', **dct)



def validate_npz(path):
    data = np.load(path)
    targets = ['x_tr_l', 'x_tr_u', 'y_tr_l', 'y_tr_u', 'x_val', 'y_val', 'x_te', 'y_te']
    missing = []
    for target in targets:
        if target not in data.__dict__['files']:
            missing.append(target)
    if len(missing) != 0:
        print('Error! Missing: ', missing)
        return

    #### check the shape ####
    x_tr_l = data['x_tr_l']
    x_tr_u = data['x_tr_u']
    y_tr_l = data['y_tr_l']
    y_tr_u = data['y_tr_u']
    x_val = data['x_val']
    y_val = data['y_val']
    x_te = data['x_te']
    y_te = data['y_te']

    if len(x_tr_l.shape) != 2:
        print('Error! x_tr_l shape wrong, except 2, found ', len(x_tr_l.shape))
    if len(x_tr_u.shape) != 2:
        print('Error! x_tr_u shape wrong, except 2, found ', len(x_tr_u.shape))
    if len(x_val.shape) != 2:
        print('Error! x_val shape wrong, except 2, found ', len(x_val.shape))
    if len(x_te.shape) != 2:
        print('Error! x_tr_u shape wrong, except 2, found ', len(x_te.shape))
    if len(y_tr_l.shape) != 1:
        print('Error! y_tr_l shape dimension wrong, except 1, found ', len(y_tr_l.shape))
    if len(y_tr_u.shape) != 1:
        print('Error! y_tr_u shape dimension wrong, except 1, found ', len(y_tr_u.shape))
    if len(y_val.shape) != 1:
        print('Error! y_val shape dimension wrong, except 1, found ', len(y_val.shape))
    if len(y_te.shape) != 1:
        print('Error! y_tr_u shape dimension wrong, except 1, found ', len(y_te.shape))

    x_s = [x_tr_l, x_tr_u, x_val, x_te]
    y_s = [y_tr_l, y_tr_u, y_val, y_te]
    posts = ['_tr_l', '_tr_u', '_val', '_te']
    for i, ele in enumerate([j for j in zip(x_s, y_s)]):
        x,y = ele
        if x.shape[0] != y.shape[0]:
            print('Error! shape of x' + posts[i] + ' is inconsistency with shape of y' + posts[i] + ' in dim 0')
            return

    ###查看标签正确性###
    for i, y in enumerate(y_s):
        # if y.dtype != 'int':
        #     print(y.dtype)
        #     print('Error! Type of y' + posts[i] + 'should be int')
        #     return

        for ele in y:
            if ele != 1 and ele != -1:
                print('Error! label y should be 1 or  -1')
                return

        if i == 0:
            if -1 in list(np.unique(y)):
                print('Error! Labeled samples should not contain negative samples')
                return

        if i == 1:
            if not 1 in list(np.unique(y)):
                print('Error! Unlabeled samples should contain some positive samples')
                return

    print('Validation succeed')


def process_stability(path='./source/stability.data', positive_label_list=[0], label_ratio = 0.1):

    columns = ["tau1", "tau2", "tau3", "tau4", "p1", "p2", "p3", "p4", "g1", "g2",
               "g3", "g4", "stab", 'stabf']
    df = pd.read_csv(path,names=columns, header=None)
    data_len = df.shape[0]    # 获取数据总长度
    df['stabf'] = df['stabf'].apply(lambda x: 1 if x in positive_label_list else -1)   # 正样本类别设为1，负样本类别为-1
    data = np.asarray(df)
    x, y = data[:,:-1].astype('float'), data[:, -1].astype('float')  # 类别需要转换为int类型
    std_scaler = MinMaxScaler()


    ### 分割数据集(60%), 验证集(20%)和测试集(20%)
    x_tr_val, x_te, y_tr_val, y_te = train_test_split(x, y, test_size=0.4, shuffle=True, stratify=y)
    x_tr, x_val, y_tr, y_val = train_test_split(x_tr_val, y_tr_val, test_size=0.16, shuffle=True, stratify=y_tr_val)

    x_tr = std_scaler.fit_transform(x_tr)  # 数据标准化
    x_val, x_te = std_scaler.transform(x_val), std_scaler.transform(x_te)

    label_num = int(label_ratio* x_tr.shape[0])  # 有标签的样本个数
    x_tr_p, y_tr_p, x_tr_n, y_tr_n = x_tr[y_tr==1,:],  y_tr[y_tr==1], x_tr[y_tr==-1,:],  y_tr[y_tr==-1] # 从训练集中分出正样本和负样本
    x_tr_l, y_tr_l = x_tr_p[:label_num, :], y_tr_p[:label_num]   # 从正样本中采样出有标签的样本
    x_tr_u = np.concatenate((x_tr_p[label_num:,:], x_tr_n[label_num:,:]), axis=0)  # 剩下的为无标签样本
    y_tr_u = np.concatenate((y_tr_p[label_num:], y_tr_n[label_num:]), axis=0)
    np.random.shuffle(x_tr_u)   # 随机打乱数据, 让无标签样本中的正负样本混合
    np.random.shuffle(y_tr_u)

    dct = {'x_tr_l': x_tr_l,
           'x_tr_u': x_tr_u,
           'y_tr_l': y_tr_l,
           'y_tr_u': y_tr_u,
           'x_val': x_val,
           'y_val': y_val,
           'x_te': x_te,
           'y_te': y_te}
    print(x_tr_l.shape, x_tr_u.shape)
    np.savez('./pu_data/stability.npz', **dct)

def process_avila(path_train, path_test, positive_label_list=['A'], label_ratio = 0.1):
    '''
    x_tr_l: 有标签的训练数据    shape: (num, feat_dim)
    x_tr_u:  无标签的训练数据    shape: (num, feat_dim)
    y_tr_l:  有标签的数据的类别  shape: (num, )
    y_tr_u:  无标签的数据的类别   shape: (num, )
    x_val:   验证数据
    y_val:   验证数据的标签
    x_te:   测试数据
    y_te:   测试数据的标签
    '''
    columns = ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10",
               "class"]
    df_train = pd.read_csv(path_train, sep=",",names=columns, header=None)
    df_test = pd.read_csv(path_test, sep=",",names=columns, header=None)

    # print(df_train['class'])
    # print(df_train['class'].groupby(df_train['class']).count())
    # print(df_test['class'].groupby(df_test['class']).count())

    df_train['class'] = df_train['class'].apply(lambda x: 1 if x in positive_label_list else -1)
    df_test['class'] = df_test['class'].apply(lambda x: 1 if x in positive_label_list else -1)   # # 正样本类别设为1，负样本类别为-1
    data_train = np.asarray(df_train)
    data_test = np.asarray(df_test)
    x_tr_val, y_tr_val =  data_train[:,:-1], data_train[:, -1]
    x_te, y_te = data_test[:,:-1], data_test[:, -1]# 类别需要转换为float64类型
    scaler = MinMaxScaler()

    ### 分割数据集(60%), 验证集(20%)和测试集(20%)
    x_tr, x_val, y_tr, y_val = train_test_split(x_tr_val, y_tr_val, test_size=0.2, shuffle=True, stratify=y_tr_val)

    x_tr = scaler.fit_transform(x_tr)  # 数据标准化
    x_val, x_te = scaler.transform(x_val), scaler.transform(x_te)

    label_num = int(label_ratio * x_tr.shape[0])  # 有标签的样本个数
    x_tr_p, y_tr_p, x_tr_n, y_tr_n = x_tr[y_tr == 1, :], y_tr[y_tr == 1], x_tr[y_tr == -1, :], y_tr[
        y_tr == -1]  # 从训练集中分出正样本和负样本
    x_tr_l, y_tr_l = x_tr_p[:label_num, :], y_tr_p[:label_num]  # 从正样本中采样出有标签的样本
    x_tr_u = np.concatenate((x_tr_p[label_num:, :], x_tr_n[label_num:, :]), axis=0)  # 剩下的为无标签样本
    y_tr_u = np.concatenate((y_tr_p[label_num:], y_tr_n[label_num:]), axis=0)

    np.random.shuffle(x_tr_u)  # 随机打乱数据, 让无标签样本中的正负样本混合
    np.random.shuffle(y_tr_u)

    dct = {'x_tr_l': x_tr_l,
           'x_tr_u': x_tr_u,
           'y_tr_l': y_tr_l,
           'y_tr_u': y_tr_u,
           'x_val': x_val,
           'y_val': y_val,
           'x_te': x_te,
           'y_te': y_te}
    # print(np.max(x_tr_l))
    np.savez('./pu_data/avila.npz', **dct)


#
# process_avila('source/avila-tr.txt', 'source/avila-ts.txt')

process_FashionMNIST()
# process_FashionMNIST()

# process_stability('source/stable_.csv')
# process_FashionMNIST()

validate_npz('./pu_data/fashionMNIST_bias.npz')
# validate_npz('./pu_data/fashionMNIST.npz')
